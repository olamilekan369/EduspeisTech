import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import Logo from '../ui/Logo';
import { NavLink } from '../ui/NavLink';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleServices = () => {
    setIsServicesOpen(!isServicesOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between">
          <Logo />
          
          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <NavLink href="#home" isScrolled={isScrolled}>Home</NavLink>
            
            <div className="relative group">
              <button 
                className={`flex items-center group-hover:text-primary-600 ${
                  isScrolled ? 'text-primary-800' : 'text-white'
                }`}
                onClick={toggleServices}
              >
                Services <ChevronDown size={16} className="ml-1" />
              </button>
              <div className="absolute left-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-1">
                  <NavLink href="#business-coaching" isDropdown>Business Coaching</NavLink>
                  <NavLink href="#it-services" isDropdown>IT Services</NavLink>
                  <NavLink href="#training-modules" isDropdown>Training Modules</NavLink>
                </div>
              </div>
            </div>
            
            <NavLink href="#about" isScrolled={isScrolled}>About Us</NavLink>
            <NavLink href="#testimonials" isScrolled={isScrolled}>Testimonials</NavLink>
            <NavLink href="#contact" isScrolled={isScrolled}>Contact</NavLink>
            
            <a 
              href="#contact" 
              className="btn btn-primary"
            >
              Get Started
            </a>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden text-primary-700"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white absolute top-full left-0 right-0 shadow-md animate-slide-down">
          <div className="container-custom py-4">
            <nav className="flex flex-col space-y-4">
              <NavLink href="#home" isMobile onClick={toggleMenu}>Home</NavLink>
              
              <div>
                <button 
                  className="flex items-center justify-between w-full text-primary-800 hover:text-primary-600"
                  onClick={toggleServices}
                >
                  Services <ChevronDown size={16} className={`transition-transform ${isServicesOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isServicesOpen && (
                  <div className="pl-4 mt-2 space-y-2 border-l-2 border-primary-100">
                    <NavLink href="#business-coaching" isMobile onClick={toggleMenu}>Business Coaching</NavLink>
                    <NavLink href="#it-services" isMobile onClick={toggleMenu}>IT Services</NavLink>
                    <NavLink href="#training-modules" isMobile onClick={toggleMenu}>Training Modules</NavLink>
                  </div>
                )}
              </div>
              
              <NavLink href="#about" isMobile onClick={toggleMenu}>About Us</NavLink>
              <NavLink href="#testimonials" isMobile onClick={toggleMenu}>Testimonials</NavLink>
              <NavLink href="#contact" isMobile onClick={toggleMenu}>Contact</NavLink>
              
              <a 
                href="#contact"
                className="btn btn-primary w-full text-center" 
                onClick={toggleMenu}
              >
                Get Started
              </a>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;