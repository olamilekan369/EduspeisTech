import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';
import Logo from '../ui/Logo';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-primary-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <Logo />
            <p className="mt-4 text-gray-300">
              Providing cutting-edge and affordable ICT solutions to improve 
              business processes and training infrastructures in the Solomon Islands.
            </p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-xl font-semibold mb-6 text-white">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-300 hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Services</a></li>
              <li><a href="#testimonials" className="text-gray-300 hover:text-white transition-colors">Testimonials</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xl font-semibold mb-6 text-white">Services</h4>
            <ul className="space-y-3">
              <li><a href="#business-coaching" className="text-gray-300 hover:text-white transition-colors">Business Coaching</a></li>
              <li><a href="#it-services" className="text-gray-300 hover:text-white transition-colors">IT Services</a></li>
              <li><a href="#software-solutions" className="text-gray-300 hover:text-white transition-colors">Software Solutions</a></li>
              <li><a href="#training-modules" className="text-gray-300 hover:text-white transition-colors">SIYB Training</a></li>
              <li><a href="#e-learning" className="text-gray-300 hover:text-white transition-colors">E-Learning Development</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xl font-semibold mb-6 text-white">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="mr-3 h-5 w-5 text-secondary-500 flex-shrink-0 mt-1" />
                <span>
                  Naha 4, East Honiara<br />
                  Guadalcanal Province<br />
                  Solomon Islands
                </span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-3 h-5 w-5 text-secondary-500 flex-shrink-0" />
                <a href="mailto:jahmegs@gmail.com" className="hover:text-secondary-400">
                  jahmegs@gmail.com
                </a>
              </li>
              <li className="flex items-center">
                <Phone className="mr-3 h-5 w-5 text-secondary-500 flex-shrink-0" />
                <a href="tel:+6777685145" className="hover:text-secondary-400">
                  +677 7685145
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-700 text-center text-gray-400">
          <p>&copy; {currentYear} Eduspeis Technologies. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;