import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/effect-fade';

const images = [
  {
    url: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    alt: "Business Training Session"
  },
  {
    url: "https://images.pexels.com/photos/7433822/pexels-photo-7433822.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    alt: "Training Workshop"
  },
  {
    url: "https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    alt: "Business Meeting"
  }
];

const HeroSection: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Slider */}
      <div className="absolute inset-0 z-0">
        <Swiper
          modules={[Autoplay, EffectFade]}
          effect="fade"
          autoplay={{
            delay: 5000,
            disableOnInteraction: false,
          }}
          loop={true}
          className="w-full h-full"
        >
          {images.map((image, index) => (
            <SwiperSlide key={index} className="w-full h-full">
              <div className="relative w-full h-full animate-bounce-slow">
                <img 
                  src={image.url}
                  alt={image.alt}
                  className="w-full h-full object-cover"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-primary-900/90 via-primary-800/80 to-primary-700/70"></div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>

      {/* Content */}
      <div className="container-custom relative z-10 pt-32 pb-24 lg:pt-0 lg:pb-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in text-white">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Welcome to <span className="text-secondary-400">Eduspeis Tech</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-lg">
              A 100% Solomon Islands-owned ICT consulting and software solutions provider, 
              specializing in Learning and Development technologies.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#contact" className="btn btn-secondary">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a href="#services" className="btn btn-outline border-white text-white hover:bg-white hover:text-primary-800">
                Explore Services
              </a>
            </div>
          </div>
          
          <div className="relative animate-slide-up hidden lg:block">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <h3 className="text-2xl font-bold text-white mb-6">Our Impact</h3>
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-secondary-500/20 rounded-lg p-4">
                    <span className="text-4xl font-bold text-secondary-400">10+</span>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">Years Experience</p>
                    <p className="text-gray-300">Combined industry expertise</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-secondary-500/20 rounded-lg p-4">
                    <span className="text-4xl font-bold text-secondary-400">100+</span>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">Entrepreneurs</p>
                    <p className="text-gray-300">Successfully trained</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-secondary-500/20 rounded-lg p-4">
                    <span className="text-4xl font-bold text-secondary-400">24/7</span>
                  </div>
                  <div>
                    <p className="text-lg font-semibold text-white">Support</p>
                    <p className="text-gray-300">Technical assistance</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;