import React from 'react';
import { CheckCircle, Award, Users, Calendar } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="section bg-gray-50">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">About Eduspeis Technologies</h2>
          <p className="text-lg text-gray-600">
            We are a 100% Solomon Islands-owned ICT consulting and software solutions provider, 
            specializing in Learning and Development technologies.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img 
                src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Eduspeis team working together" 
                className="w-full h-auto object-cover"
              />
            </div>
            
            {/* Floating foundation year card */}
            <div className="absolute -right-6 -bottom-6 bg-primary-700 text-white p-6 rounded-lg shadow-xl max-w-[180px] hidden md:block">
              <Calendar className="h-8 w-8 mb-2 text-secondary-400" />
              <p className="text-sm">Founded</p>
              <p className="text-2xl font-bold">2021</p>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold mb-6">Our Story</h3>
            <p className="text-gray-700 mb-6">
              Eduspeis Technologies was founded in 2021 as an innovative response to the COVID-19 pandemic, 
              addressing critical gaps in education accessibility. The idea was conceived during the Ennovation 
              Blo Iumi (EBI) Program, an initiative by the Young Entrepreneurs Council of Solomon Islands (YECSI), 
              designed to foster innovative solutions to challenges posed by the pandemic.
            </p>
            <p className="text-gray-700 mb-8">
              At the height of COVID-19, school closures and the absence of continuity plans left students without 
              access to learning materials. Recognizing this urgent need, we developed a comprehensive e-learning 
              platform to enable schools to provide uninterrupted access to educational resources anytime, anywhere.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-success-500 flex-shrink-0 mt-1" />
                <div className="ml-3">
                  <h4 className="font-semibold mb-1">Expert Team</h4>
                  <p className="text-gray-600">Over 10 years of combined experience</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-success-500 flex-shrink-0 mt-1" />
                <div className="ml-3">
                  <h4 className="font-semibold mb-1">Local Knowledge</h4>
                  <p className="text-gray-600">100% Solomon Islands owned</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-success-500 flex-shrink-0 mt-1" />
                <div className="ml-3">
                  <h4 className="font-semibold mb-1">Award Winning</h4>
                  <p className="text-gray-600">Top 3 winner in EBI Program</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle className="h-6 w-6 text-success-500 flex-shrink-0 mt-1" />
                <div className="ml-3">
                  <h4 className="font-semibold mb-1">Innovation Focus</h4>
                  <p className="text-gray-600">Cutting-edge technology solutions</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Mission and Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-24">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <div className="inline-block p-3 bg-primary-100 rounded-lg mb-4">
              <Award className="h-8 w-8 text-primary-700" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Our Mission</h3>
            <p className="text-gray-700">
              To provide cutting edge and affordable ICT software and hardware technologies and services to the 
              Solomon Islands to improve the way organizational business processes are conducted and to provide 
              a platform for improved Training and Development infrastructures.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-md">
            <div className="inline-block p-3 bg-primary-100 rounded-lg mb-4">
              <Users className="h-8 w-8 text-primary-700" />
            </div>
            <h3 className="text-xl font-semibold mb-4">Our Vision</h3>
            <p className="text-gray-700">
              To be the leading provider of innovative, cost-effective Training and ICT solutions in the 
              Solomon Islands, empowering businesses, institutions, and communities through cutting-edge 
              technology and expert-driven services.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;