import React from 'react';
import { Lightbulb, Server, Laptop, BookOpen, BarChart, FileCode, Network, PenTool } from 'lucide-react';
import ServiceCard from '../ui/ServiceCard';

const ServicesSection: React.FC = () => {
  const services = [
    {
      id: 'business-coaching',
      title: 'Business Coaching',
      description: 'Personalized coaching using ILO-SIYB methodology to help entrepreneurs build sustainable businesses.',
      icon: <Lightbulb className="h-6 w-6" />,
      bgColor: 'bg-primary-50',
      iconColor: 'text-primary-600',
    },
    {
      id: 'it-services',
      title: 'IT Support Services',
      description: 'Comprehensive IT support for businesses including hardware, software, and network troubleshooting.',
      icon: <Server className="h-6 w-6" />,
      bgColor: 'bg-secondary-50',
      iconColor: 'text-secondary-600',
    },
    {
      id: 'software-solutions',
      title: 'Software Solutions',
      description: 'Custom software development and implementation of business management systems.',
      icon: <Laptop className="h-6 w-6" />,
      bgColor: 'bg-accent-50',
      iconColor: 'text-accent-600',
    },
    {
      id: 'training-modules',
      title: 'SIYB Training Modules',
      description: 'Structured entrepreneurship training programs using ILO\'s internationally recognized methodology.',
      icon: <BookOpen className="h-6 w-6" />,
      bgColor: 'bg-success-50',
      iconColor: 'text-success-600',
    },
    {
      id: 'business-analysis',
      title: 'Business Analysis',
      description: 'Data-driven analysis to identify opportunities for business growth and improvement.',
      icon: <BarChart className="h-6 w-6" />,
      bgColor: 'bg-primary-50',
      iconColor: 'text-primary-600',
    },
    {
      id: 'web-development',
      title: 'Web Development',
      description: 'Modern, responsive website design and development for businesses.',
      icon: <FileCode className="h-6 w-6" />,
      bgColor: 'bg-secondary-50',
      iconColor: 'text-secondary-600',
    },
    {
      id: 'network-solutions',
      title: 'Network Solutions',
      description: 'LAN/WAN design and implementation for businesses and educational institutions.',
      icon: <Network className="h-6 w-6" />,
      bgColor: 'bg-accent-50',
      iconColor: 'text-accent-600',
    },
    {
      id: 'e-learning',
      title: 'E-Learning Development',
      description: 'Custom e-learning platforms and content development for educational institutions.',
      icon: <PenTool className="h-6 w-6" />,
      bgColor: 'bg-success-50',
      iconColor: 'text-success-600',
    },
  ];

  return (
    <section id="services" className="section">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Services</h2>
          <p className="text-lg text-gray-600">
            We offer a comprehensive range of business coaching and IT services 
            tailored to meet the unique needs of Solomon Islands entrepreneurs and organizations.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
        
        {/* Featured Service - SIYB Training */}
        <div className="mt-20 bg-primary-50 rounded-xl overflow-hidden" id="training-modules">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <h3 className="text-2xl md:text-3xl font-bold mb-6">ILO-SIYB Training Program</h3>
              <p className="text-gray-700 mb-6">
                The Start and Improve Your Business (SIYB) program is a management training program 
                developed by the International Labour Organization (ILO) with a focus on 
                starting and improving small businesses.
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary-100 flex items-center justify-center mr-3 mt-1">
                    <span className="text-primary-700 font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Generate Your Business Idea (GYB)</h4>
                    <p className="text-gray-600">For potential entrepreneurs who want to identify viable business ideas</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary-100 flex items-center justify-center mr-3 mt-1">
                    <span className="text-primary-700 font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Start Your Business (SYB)</h4>
                    <p className="text-gray-600">For potential entrepreneurs ready to start a small business</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary-100 flex items-center justify-center mr-3 mt-1">
                    <span className="text-primary-700 font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Improve Your Business (IYB)</h4>
                    <p className="text-gray-600">For existing entrepreneurs who want to improve their business</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 rounded-full bg-primary-100 flex items-center justify-center mr-3 mt-1">
                    <span className="text-primary-700 font-bold text-sm">4</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Expand Your Business (EYB)</h4>
                    <p className="text-gray-600">For entrepreneurs who want to expand their business</p>
                  </div>
                </div>
              </div>
              
              <a href="#contact" className="btn btn-primary">
                Inquire About Training
              </a>
            </div>
            
            <div className="relative h-full min-h-[320px]">
              <img 
                src="https://images.pexels.com/photos/7433822/pexels-photo-7433822.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="SIYB Training Session" 
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;