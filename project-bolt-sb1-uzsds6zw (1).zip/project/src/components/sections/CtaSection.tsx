import React from 'react';
import { ArrowRight } from 'lucide-react';

const CtaSection: React.FC = () => {
  return (
    <section className="bg-primary-700 py-16">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-lg text-gray-200 mb-8">
            Contact us today to learn how our business coaching and IT services 
            can help your organization grow and succeed.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#contact" className="btn btn-secondary">
              Get in Touch
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a href="#services" className="btn bg-white text-primary-700 hover:bg-gray-100">
              Explore Our Services
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;