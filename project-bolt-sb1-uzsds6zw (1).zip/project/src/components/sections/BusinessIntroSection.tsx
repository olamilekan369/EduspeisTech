import React from 'react';
import { ArrowRight, Award, Users, Lightbulb } from 'lucide-react';

const BusinessIntroSection: React.FC = () => {
  return (
    <section className="section bg-gray-50" data-aos="fade-up">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative" data-aos="fade-right">
            <img 
              src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              alt="Training of Trainers Session"
              className="rounded-lg shadow-xl w-full h-auto"
            />
            <div 
              className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-xl hidden md:block"
              data-aos="fade-up"
              data-aos-delay="200"
            >
              <Award className="h-8 w-8 text-primary-600 mb-2" />
              <p className="text-sm text-gray-600">Established</p>
              <p className="text-2xl font-bold text-primary-800">2021</p>
            </div>
          </div>

          <div className="space-y-6" data-aos="fade-left">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900">
              Transforming Business Education in Solomon Islands
            </h2>
            
            <p className="text-lg text-gray-700">
              Born from innovation during the COVID-19 pandemic, Eduspeis Technologies emerged as a pioneering force in the Solomon Islands' digital education landscape. As winners of the Ennovation Blo Iumi (EBI) Program, we've proven our commitment to revolutionary learning solutions.
            </p>

            <p className="text-lg text-gray-700">
              Our journey began with a vision to bridge critical gaps in education accessibility, leading to the development of comprehensive e-learning platforms that ensure uninterrupted access to quality educational resources.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
              <div className="bg-white p-4 rounded-lg shadow-md">
                <Lightbulb className="h-8 w-8 text-primary-600 mb-2" />
                <h3 className="font-semibold text-lg">Innovation</h3>
                <p className="text-gray-600">Cutting-edge learning solutions</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-md">
                <Users className="h-8 w-8 text-primary-600 mb-2" />
                <h3 className="font-semibold text-lg">Community</h3>
                <p className="text-gray-600">Local expertise & support</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-md">
                <Award className="h-8 w-8 text-primary-600 mb-2" />
                <h3 className="font-semibold text-lg">Excellence</h3>
                <p className="text-gray-600">Award-winning programs</p>
              </div>
            </div>

            <div className="pt-6" data-aos="fade-up" data-aos-delay="300">
              <a href="#services" className="btn btn-primary">
                Explore Our Solutions
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessIntroSection;