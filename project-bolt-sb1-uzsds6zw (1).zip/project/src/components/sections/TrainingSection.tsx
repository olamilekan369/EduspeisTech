import React from 'react';
import { Award, CheckCircle } from 'lucide-react';

const TrainingSection: React.FC = () => {
  return (
    <section className="section bg-gray-50" data-aos="fade-up">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative" data-aos="fade-right">
            <img 
              src="/images/siyb-training-2.jpg"
              alt="SIYB Training Graduates"
              className="rounded-lg shadow-xl w-full h-auto"
            />
            <div 
              className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-xl hidden md:block"
              data-aos="fade-up"
              data-aos-delay="200"
            >
              <Award className="h-8 w-8 text-primary-600 mb-2" />
              <p className="text-sm text-gray-600">ILO Certified</p>
              <p className="text-xl font-bold text-primary-800">SIYB Training</p>
            </div>
          </div>

          <div className="space-y-6" data-aos="fade-left">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900">
              Empowering Local Entrepreneurs
            </h2>
            
            <p className="text-lg text-gray-700">
              At Eduspeis Technologies, we're committed to fostering entrepreneurial growth in the Solomon Islands through our comprehensive SIYB (Start and Improve Your Business) training program, certified by the International Labour Organization (ILO).
            </p>

            <div className="space-y-4">
              <div className="flex items-start" data-aos="fade-up" data-aos-delay="100">
                <CheckCircle className="h-6 w-6 text-primary-600 mt-1 flex-shrink-0" />
                <div className="ml-4">
                  <h4 className="font-semibold text-lg">Customized Training Modules</h4>
                  <p className="text-gray-600">From generating business ideas to expanding existing enterprises, our modules cater to entrepreneurs at every stage.</p>
                </div>
              </div>

              <div className="flex items-start" data-aos="fade-up" data-aos-delay="200">
                <CheckCircle className="h-6 w-6 text-primary-600 mt-1 flex-shrink-0" />
                <div className="ml-4">
                  <h4 className="font-semibold text-lg">Local Expertise</h4>
                  <p className="text-gray-600">Our trainers understand the unique challenges and opportunities in the Solomon Islands business landscape.</p>
                </div>
              </div>

              <div className="flex items-start" data-aos="fade-up" data-aos-delay="300">
                <CheckCircle className="h-6 w-6 text-primary-600 mt-1 flex-shrink-0" />
                <div className="ml-4">
                  <h4 className="font-semibold text-lg">Technology Integration</h4>
                  <p className="text-gray-600">We combine traditional business training with modern digital solutions to give entrepreneurs a competitive edge.</p>
                </div>
              </div>
            </div>

            <div className="pt-6" data-aos="fade-up" data-aos-delay="400">
              <a href="#contact" className="btn btn-primary">
                Start Your Business Journey
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrainingSection;