import React from 'react';
import { Linkedin, Mail } from 'lucide-react';

const teamMembers = [
  {
    id: 1,
    name: 'John Smith',
    position: 'CEO & Founder',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'John has over 10 years of experience in IT consulting and business development.',
    linkedin: '#',
    email: 'john@eduspeistech.com',
  },
  {
    id: 2,
    name: 'Sarah Wilson',
    position: 'Business Coach',
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Sarah is a certified ILO-SIYB trainer with expertise in entrepreneurship development.',
    linkedin: '#',
    email: 'sarah@eduspeistech.com',
  },
  {
    id: 3,
    name: 'Michael Rogers',
    position: 'IT Solutions Specialist',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Michael leads our IT services team, specializing in software implementation and support.',
    linkedin: '#',
    email: 'michael@eduspeistech.com',
  },
  {
    id: 4,
    name: 'Rebecca Chen',
    position: 'E-Learning Developer',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
    bio: 'Rebecca designs innovative e-learning solutions for educational institutions.',
    linkedin: '#',
    email: 'rebecca@eduspeistech.com',
  },
];

const TeamSection: React.FC = () => {
  return (
    <section id="team" className="section bg-gray-50">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Team</h2>
          <p className="text-lg text-gray-600">
            Meet our team of experienced professionals dedicated to helping your business succeed.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member) => (
            <div key={member.id} className="card group">
              <div className="relative overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-64 object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                  <div className="flex space-x-3 mb-2">
                    <a 
                      href={member.linkedin} 
                      className="bg-white/20 hover:bg-white/40 p-2 rounded-full backdrop-blur-sm transition-colors duration-200"
                      aria-label={`${member.name}'s LinkedIn`}
                    >
                      <Linkedin className="h-5 w-5 text-white" />
                    </a>
                    <a 
                      href={`mailto:${member.email}`} 
                      className="bg-white/20 hover:bg-white/40 p-2 rounded-full backdrop-blur-sm transition-colors duration-200"
                      aria-label={`Email ${member.name}`}
                    >
                      <Mail className="h-5 w-5 text-white" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                <p className="text-primary-600 mb-3">{member.position}</p>
                <p className="text-gray-600">{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;