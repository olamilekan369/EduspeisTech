import React from 'react';

interface ServiceProps {
  service: {
    id: string;
    title: string;
    description: string;
    icon: React.ReactNode;
    bgColor: string;
    iconColor: string;
  };
}

const ServiceCard: React.FC<ServiceProps> = ({ service }) => {
  return (
    <div id={service.id} className="card group hover:-translate-y-2">
      <div className="p-6">
        <div className={`inline-block p-3 rounded-lg mb-4 ${service.bgColor} ${service.iconColor}`}>
          {service.icon}
        </div>
        <h3 className="text-xl font-semibold mb-3 group-hover:text-primary-600 transition-colors">
          {service.title}
        </h3>
        <p className="text-gray-600">
          {service.description}
        </p>
      </div>
    </div>
  );
};

export default ServiceCard;