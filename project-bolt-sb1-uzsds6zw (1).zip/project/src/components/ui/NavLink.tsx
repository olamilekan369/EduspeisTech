import React from 'react';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  isDropdown?: boolean;
  isMobile?: boolean;
  isScrolled?: boolean;
  onClick?: () => void;
}

export const NavLink: React.FC<NavLinkProps> = ({
  href,
  children,
  isDropdown = false,
  isMobile = false,
  isScrolled = false,
  onClick,
}) => {
  if (isDropdown) {
    return (
      <a
        href={href}
        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
        onClick={onClick}
      >
        {children}
      </a>
    );
  }

  if (isMobile) {
    return (
      <a
        href={href}
        className="block text-primary-800 hover:text-primary-600 font-medium"
        onClick={onClick}
      >
        {children}
      </a>
    );
  }

  return (
    <a
      href={href}
      className={`font-medium transition-colors duration-300 hover:text-primary-600 ${
        isScrolled ? 'text-primary-800' : 'text-white'
      }`}
      onClick={onClick}
    >
      {children}
    </a>
  );
};