import React from 'react';
import { Lightbulb } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <a href="#" className="flex items-center">
      <div className="flex items-center">
        <Lightbulb className="h-8 w-8 text-primary-600" />
        <div className="ml-2">
          <span className="text-primary-700 font-bold text-xl">Eduspeis</span>
          <span className="text-secondary-600 font-medium text-xl">Tech</span>
        </div>
      </div>
    </a>
  );
};

export default Logo;