import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageCircle } from 'lucide-react';

interface Message {
  text: string;
  isBot: boolean;
}

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { text: "Hello! I'm the Eduspeis Tech assistant. How can I help you today?", isBot: true }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { text: userMessage, isBot: false }]);

    // Simulate bot thinking
    setTimeout(() => {
      const botResponse = generateResponse(userMessage);
      setMessages(prev => [...prev, { text: botResponse, isBot: true }]);
    }, 1000);
  };

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('siyb') || lowerMessage.includes('training')) {
      return "Our SIYB (Start and Improve Your Business) training program is an ILO-certified methodology designed to help entrepreneurs start and grow their businesses. We offer modules in Generate Your Business Idea (GYB), Start Your Business (SYB), Improve Your Business (IYB), and Expand Your Business (EYB). Would you like to learn more about a specific module?";
    }
    
    if (lowerMessage.includes('it support') || lowerMessage.includes('technical support')) {
      return "We provide comprehensive IT support services including hardware troubleshooting, software installation, network setup, and system maintenance. Our team is available 24/7 to assist with any technical issues.";
    }
    
    if (lowerMessage.includes('software') || lowerMessage.includes('license')) {
      return "We offer software licensing solutions for various business needs. This includes operating systems, productivity suites, security software, and specialized business applications. Would you like to know about specific software packages?";
    }
    
    if (lowerMessage.includes('contact') || lowerMessage.includes('location')) {
      return "You can find us at:\nNaha 4, East Honiara\nGuadalcanal Province\nSolomon Islands\n\nP.O Box 1559\nHoniara\nSolomon Islands\n\nEmail: jahmegs@gmail.com\nPhone: +677 7685145";
    }
    
    if (lowerMessage.includes('cost') || lowerMessage.includes('price') || lowerMessage.includes('fee')) {
      return "Our pricing varies depending on the specific service or training program. Please contact us directly for a customized quote based on your needs.";
    }

    return "I can help you with information about our SIYB training programs, IT support services, software licensing, and general inquiries. What specific information are you looking for?";
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-primary-700 text-white p-4 rounded-full shadow-lg hover:bg-primary-800 transition-colors"
        >
          <MessageCircle className="h-6 w-6" />
        </button>
      )}

      {isOpen && (
        <div className="bg-white rounded-lg shadow-xl w-80 sm:w-96 max-h-[600px] flex flex-col">
          <div className="bg-primary-700 text-white p-4 rounded-t-lg flex justify-between items-center">
            <h3 className="font-semibold">Eduspeis Tech Assistant</h3>
            <button onClick={() => setIsOpen(false)} className="text-white hover:text-gray-200">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[400px]">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.isBot
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-primary-700 text-white'
                  }`}
                >
                  <p className="whitespace-pre-line">{message.text}</p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your message..."
                className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <button
                onClick={handleSend}
                className="bg-primary-700 text-white p-2 rounded-lg hover:bg-primary-800 transition-colors"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatBot;