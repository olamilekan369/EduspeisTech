/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#E6E7EF',
          100: '#C2C4D8',
          200: '#9A9DBE',
          300: '#7276A4',
          400: '#4F5891',
          500: '#2D3A7D',
          600: '#24306A',
          700: '#1B1F3B', // Main brand color
          800: '#131529',
          900: '#0A0A18',
        },
        secondary: {
          50: '#E6F6FF',
          100: '#BDEAFE',
          200: '#8CD8FD',
          300: '#5AC5FC',
          400: '#28B3FB',
          500: '#0EA0FA',
          600: '#0C88D5',
          700: '#0A70B0',
          800: '#08588C',
          900: '#064067',
        },
        accent: {
          50: '#FFF3E6',
          100: '#FEDFC2',
          200: '#FCC899',
          300: '#FBB170',
          400: '#FA9B47',
          500: '#F9841E',
          600: '#D57018',
          700: '#B15C12',
          800: '#8D490E',
          900: '#693509',
        },
        success: {
          500: '#10B981',
          600: '#0E9F6E',
        },
        warning: {
          500: '#F59E0B',
          600: '#D97706',
        },
        error: {
          500: '#EF4444',
          600: '#DC2626',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        heading: ['Poppins', 'Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-down': 'slideDown 0.5s ease-out',
        'bounce-slow': 'bounceSlow 15s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        bounceSlow: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-20px)' },
        },
      },
    },
  },
  plugins: [],
};